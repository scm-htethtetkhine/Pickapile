export interface Ianswer {
    AnswerId: number;
  AnswerImageUrl: string;
  AnswerName: string;
  AnswerDesp: string;
  QuestionId: number;
}
