export interface Iquestion {
    QuestionId: number;
  QuestionName: string;
  QuestionDesp: string;
}
