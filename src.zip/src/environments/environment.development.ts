export const environment = {
    apiURL:"http://localhost:3000"
};
